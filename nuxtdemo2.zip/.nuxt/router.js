import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _45d6686f = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages_about" */))
const _bace2502 = () => interopDefault(import('..\\pages\\notes\\index.vue' /* webpackChunkName: "pages_notes_index" */))
const _1c34410a = () => interopDefault(import('..\\pages\\project.vue' /* webpackChunkName: "pages_project" */))
const _8fb207c0 = () => interopDefault(import('..\\pages\\test.vue' /* webpackChunkName: "pages_test" */))
const _363243a7 = () => interopDefault(import('..\\pages\\notes\\_id.vue' /* webpackChunkName: "pages_notes__id" */))
const _658e4334 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _45d6686f,
    name: "about"
  }, {
    path: "/notes",
    component: _bace2502,
    name: "notes"
  }, {
    path: "/project",
    component: _1c34410a,
    name: "project"
  }, {
    path: "/test",
    component: _8fb207c0,
    name: "test"
  }, {
    path: "/notes/:id",
    component: _363243a7,
    name: "notes-id"
  }, {
    path: "/",
    component: _658e4334,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}

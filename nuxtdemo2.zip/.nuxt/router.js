import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _45d6686f = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages_about" */))
const _68fc6ac6 = () => interopDefault(import('..\\pages\\info\\index.vue' /* webpackChunkName: "pages_info_index" */))
const _bace2502 = () => interopDefault(import('..\\pages\\notes\\index.vue' /* webpackChunkName: "pages_notes_index" */))
const _1c34410a = () => interopDefault(import('..\\pages\\project.vue' /* webpackChunkName: "pages_project" */))
const _d085173c = () => interopDefault(import('..\\pages\\test\\index.vue' /* webpackChunkName: "pages_test_index" */))
const _7dc4e5fc = () => interopDefault(import('..\\pages\\effects\\first.vue' /* webpackChunkName: "pages_effects_first" */))
const _17db32a4 = () => interopDefault(import('..\\pages\\info\\_id.vue' /* webpackChunkName: "pages_info__id" */))
const _363243a7 = () => interopDefault(import('..\\pages\\notes\\_id.vue' /* webpackChunkName: "pages_notes__id" */))
const _4381274a = () => interopDefault(import('..\\pages\\test\\_id.vue' /* webpackChunkName: "pages_test__id" */))
const _658e4334 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _45d6686f,
    name: "about"
  }, {
    path: "/info",
    component: _68fc6ac6,
    name: "info"
  }, {
    path: "/notes",
    component: _bace2502,
    name: "notes"
  }, {
    path: "/project",
    component: _1c34410a,
    name: "project"
  }, {
    path: "/test",
    component: _d085173c,
    name: "test"
  }, {
    path: "/effects/first",
    component: _7dc4e5fc,
    name: "effects-first"
  }, {
    path: "/info/:id",
    component: _17db32a4,
    name: "info-id"
  }, {
    path: "/notes/:id",
    component: _363243a7,
    name: "notes-id"
  }, {
    path: "/test/:id",
    component: _4381274a,
    name: "test-id"
  }, {
    path: "/",
    component: _658e4334,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}

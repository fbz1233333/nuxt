import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _45d6686f = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages_about" */))
const _1f46c4b6 = () => interopDefault(import('..\\pages\\diary.vue' /* webpackChunkName: "pages_diary" */))
const _00e2d9a3 = () => interopDefault(import('..\\pages\\notes.vue' /* webpackChunkName: "pages_notes" */))
const _1c34410a = () => interopDefault(import('..\\pages\\project.vue' /* webpackChunkName: "pages_project" */))
const _8fb207c0 = () => interopDefault(import('..\\pages\\test.vue' /* webpackChunkName: "pages_test" */))
const _658e4334 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _45d6686f,
    name: "about"
  }, {
    path: "/diary",
    component: _1f46c4b6,
    name: "diary"
  }, {
    path: "/notes",
    component: _00e2d9a3,
    name: "notes"
  }, {
    path: "/project",
    component: _1c34410a,
    name: "project"
  }, {
    path: "/test",
    component: _8fb207c0,
    name: "test"
  }, {
    path: "/",
    component: _658e4334,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
